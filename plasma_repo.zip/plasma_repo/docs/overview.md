# Plasma Project Overview

Plasma improves transaction throughput while maintaining blockchain security guarantees.
